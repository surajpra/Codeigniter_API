<!DOCTYPE html>
<html>
<head>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
  <title>Dashboard</title>
</head>
<body>


<div class="container">
  <div class="col-md-12">
    
    <div class="row">
      Welcome <?php echo $this->session->userdata('USERNAME'); ?>
  </div>

   <?php  
         foreach ($show->result() as $row)  
         {  
            ?><tr>  
            <td><?php echo $row->name;?></td>  
            <td><?php echo $row->email;?></td>  
            </tr>  
         <?php }  
         ?>  <br><br><br><br><br>
         <a href="<?php echo base_url();?>index.php/auth/ulogout">Logout</a>
</div>
  </div>
</div>
</body>
</html>