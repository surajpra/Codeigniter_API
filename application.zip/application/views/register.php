<!DOCTYPE html>
<html>
<head>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
  <title><?php echo $title ?></title>
</head>
<body>


<div class="container">
  <div class="col-md-12">
    <?php echo validation_errors(); ?>

     <?php if(isset($_SESSION['error'])){ ?>
      <div class="alert alert-danger"><?php echo $_SESSION['error']; ?></div>
    <?php } ?>
    
    <div class="row">

      <?php echo form_open_multipart('auth/uregister');?>
      <fieldset>

      <!-- Form Name -->
      <legend><?php echo $title ?></legend>

      <!-- Text input-->
      <div class="form-group">
        <label class="col-md-12 control-label" for="textinput">Name:</label>  
        <div class="col-md-12">
        <input name="textinput" class="form-control input-md" id="textinput" type="text" placeholder="Name">
          
        </div>
      </div>

      <!-- Text input-->
      <div class="form-group">
        <label class="col-md-12 control-label" for="E-mail">E-mail:</label>  
        <div class="col-md-12">
        <input name="emailinput" class="form-control input-md" id="E-mail" type="email" placeholder="E-mail">
          
        </div>
      </div>

      <!-- Password input-->
      <div class="form-group">
        <label class="col-md-12 control-label" for="passwordinput">Password:</label>
        <div class="col-md-12">
          <input name="passwordinput" class="form-control input-md" id="passwordinput" type="password" placeholder="Password">
          
        </div>
      </div>

      <!-- File Button --> 
      <div class="form-group">
        <label class="col-md-12 control-label" for="filebutton">Upload Image</label>
        <div class="col-md-12">
          <input name="filebutton" class="input-file" id="filebutton" type="file">
        </div>
      </div>

      <!-- Button -->
      <div class="form-group">
        <label class="col-md-12 control-label" for="singlebutton">Submit</label>
        <div class="col-md-12">
          <button name="register" class="btn btn-primary" id="singlebutton">Button</button>
        </div>
      </div>

      </fieldset>
</form>

  </div>
</div>
  </div>
</div>
</body>
</html>