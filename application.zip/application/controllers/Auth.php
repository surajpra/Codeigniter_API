<?php
defined('BASEPATH') OR exit('No direct script access allowed');

date_default_timezone_set('Asia/Kolkata');

class Auth extends CI_Controller {

	public function __construct(){
		parent::__construct();
		//$this->load->model('auth_model');
	}

	public function uregister()
	{
		if(isset($_POST['register'])){
			$this->form_validation->set_rules('textinput','username','required|xss_clean|is_unique[users.name]');
			$this->form_validation->set_rules('emailinput','email','valid_email|required|xss_clean|is_unique[users.email]');
			$this->form_validation->set_rules('passwordinput','password','min_length[8]|required|xss_clean');
			if (empty($_FILES['filebutton']['name']))
			{
			    $this->form_validation->set_rules('filebutton', 'Image', 'required');
			}
			$this->form_validation->set_error_delimiters('<div class="alert alert-danger">', '</div>');
			$this->form_validation->set_message('is_unique', 'The %s is already taken.');

			if($this->form_validation->run() == TRUE)
			{	
				$hash = $this->input->post('passwordinput');
				//$pass = $this->encryption->encrypt($hash);
				$pass = md5($hash);
				$file = $this->upload_ufile();
				$data = array(
					'name' => $this->input->post('textinput'),
					'pass' => $pass,
					'email' => $this->input->post('emailinput'),
					'file' => $file,
					'date' => date('Y-m-d h:i:sa')
				);

				$this->db->insert('users',$data);
				$this->session->set_flashdata("success","Your Account Has Been Created Succesfully. You Can Login Now.");
				redirect("auth/ulogin","refresh");
			}
			else{
				$data['title'] = "Register Page";
				$this->load->view('register',$data);
			}
		}
		else{
			$data['title'] = "Register Page";
			$this->load->view('register',$data);
		}
	}


	public function upload_ufile()
	{
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		$config['max_size']	= '100000';
		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload('filebutton'))
		{
			$error = array('error' => $this->upload->display_errors());
			$this->session->set_flashdata('error',$error['error']);
         	redirect('auth/uregister','refresh');
		}
		else
		{
			$data = array('upload_data' => $this->upload->data());
			return $data['upload_data']['full_path'];
		}
	}

	public function ulogin()
	{
		if(isset($_POST['register'])){
			$this->form_validation->set_rules('textinput','username','required|xss_clean');
			$this->form_validation->set_rules('passwordinput','password','min_length[8]|required|xss_clean');
			$this->form_validation->set_error_delimiters('<div class="alert alert-danger">', '</div>');

			if($this->form_validation->run()==TRUE){
				$uname = $this->input->post('textinput'); 
				$hash = $this->input->post('passwordinput');
				//$upass = $this->encryption->encrypt($hash);
				$upass =  md5($hash);
				$this->db->select('*');
				$this->db->from('users');
				$this->db->where(array('name'=>$uname, 'pass'=> $upass));
				$query = $this->db->get();
				$user = $query->row();		
				if($user->name){
					$this->session->set_flashdata('success','You are logged in now.');
					$usrsessn = array('LOGGED_IN'=>TRUE,'USERNAME'=>$user->name,'EMAIL'=>$user->email);
					$this->session->set_userdata($usrsessn);
					redirect('profile/dashboard','refresh');
				}
				else{
					$this->session->set_flashdata('error','User is not registered. Please Register.');
					//redirect('auth/ulogin','refresh');
				}
			}
			else{
				echo "false";
			}
		}

		$data['title'] = "Login Page";
		$this->load->view('login',$data);
	}

	public function ulogout()
	{
		$logout = array('LOGGED_IN'=>'','USERNAME'=>'','EMAIL'=>'');
		$this->session->unset_userdata($logout);
		$this->session->sess_destroy();
		$this->session->set_flashdata('success','You are successfully logged out');
		redirect('auth/ulogin','refresh');
	}

}