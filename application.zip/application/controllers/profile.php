<?php 
 /**
  * 
  */
 class Profile extends CI_Controller
 {
 	
 	function __construct()
 	{
 		parent::__construct();
 		if($this->session->userdata('LOGGED_IN') == FALSE){
 			$this->session->set_flashdata('error','Please Login');
 			redirect('auth/ulogin', 'refresh');
 		}
 	}

 	function Dashboard(){
 		$this->load->model('Dashboard_Model');
        $data['show']=$this->Dashboard_Model->select();
 		$this->load->view('dashboard',$data);
 	}
 }


 ?>