<?php  
   class Dashboard_Model extends CI_Model  
   {  
      function __construct()  
      {  
         parent::__construct();  
      }  
      public function select()  
      { 
      	$query = $this->db->get('users');  
        return $query;  
      }  
   }  
?>  